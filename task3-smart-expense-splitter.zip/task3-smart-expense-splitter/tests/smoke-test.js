/* SplitSmart smoke test — runs the real page in jsdom and drives the UI. */
/* ============================================================
   SplitSmart — smoke test
   Runs the real index.html inside jsdom and drives the UI the
   way a user would (clicks, typing, submitting), then asserts
   that the money maths, edit/delete/undo, persistence and
   empty states all behave.

   Usage:
     npm init -y && npm i -D jsdom
     node tests/smoke-test.js
   ============================================================ */
const fs = require("fs");
const path = require("path");
const { JSDOM } = require("jsdom");

const html = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");

let failures = 0, checks = 0;
function ok(cond, label, extra){
  checks++;
  if(cond){ console.log("  ✓ " + label); }
  else { failures++; console.log("  ✗ " + label + (extra !== undefined ? "  →  " + JSON.stringify(extra) : "")); }
}
function section(t){ console.log("\n" + t); }

const dom = new JSDOM(html, {
  runScripts: "dangerously",
  pretendToBeVisual: true,
  url: "http://localhost/",
  beforeParse(window){
    window.Element.prototype.scrollIntoView = function(){};
    window.print = function(){};
    window.HTMLElement.prototype.scrollIntoView = function(){};
  }
});
const { window } = dom;
const { document } = window;

// let init() run
setTimeout(runTests, 50);

function $(sel){ return document.querySelector(sel); }
function $$(sel){ return Array.from(document.querySelectorAll(sel)); }
function submitForm(){
  $("#expenseForm").dispatchEvent(new window.Event("submit", { bubbles:true, cancelable:true }));
}
function setVal(node, v){ node.value = v; node.dispatchEvent(new window.Event("input", { bubbles:true })); }

function runTests(){
  const API = window.SplitSmart;
  let st = API.getState();

  section("1. Boot / first-run demo");
  ok(!!API, "window.SplitSmart debug API is exposed");
  ok(st.people.length === 5, "demo trip loads 5 people", st.people.length);
  ok(st.expenses.length === 6, "demo trip loads 6 expenses", st.expenses.length);
  ok($("#groupName").value === "Goa Trip 2026", "group name hydrated into header", $("#groupName").value);
  ok($$("#peopleList .chip").length === 5, "people list renders 5 chips");
  ok($$("#expenseList .exp").length === 6, "ledger renders 6 rows");
  ok($$("#balanceList .bal").length === 5, "balances render 5 rows");
  ok($$("#settlementList .set-row").length > 0, "settlement plan renders at least one transfer");

  section("2. Money-math invariants (the core of the task)");
  let L = API.ledger();
  const netSum = Object.values(L.net).reduce((a,b)=>a+b,0);
  ok(netSum === 0, "sum of all net balances is exactly 0", netSum);

  const total = L.total;
  const paidSum = Object.values(L.paid).reduce((a,b)=>a+b,0);
  const shareSum = Object.values(L.share).reduce((a,b)=>a+b,0);
  ok(paidSum === total, "total paid == total spent", { paidSum, total });
  ok(shareSum === total, "total shares == total spent", { shareSum, total });

  let transfers = API.settleUp(L.net);
  const posSum = Object.values(L.net).filter(v=>v>0).reduce((a,b)=>a+b,0);
  const tSum = transfers.reduce((a,t)=>a+t.amount,0);
  ok(tSum === posSum, "settlement transfers cover exactly what creditors are owed", { tSum, posSum });
  ok(transfers.length <= st.people.length - 1, "settlement uses at most people-1 transfers", transfers.length);
  transfers.forEach(t => { ok(t.from !== t.to && t.amount > 0, "transfer " + st.people.find(p=>p.id===t.from).name + " → " + st.people.find(p=>p.id===t.to).name + " is valid (" + t.amount/100 + ")"); });

  const alloc = API.allocate(1000, [1,1,1]);
  ok(alloc.join(",") === "334,333,333", "allocate(1000, 3) = 334/333/333 (exact paise distribution)", alloc);
  ok(API.allocate(1, [1,1,1]).reduce((a,b)=>a+b,0) === 1, "allocate(1 paise, 3 people) still sums exactly", API.allocate(1,[1,1,1]));
  ok(API.allocate(999, [0.5,0.3,0.2]).reduce((a,b)=>a+b,0) === 999, "weighted percent allocation stays exact");

  section("3. Add a person");
  setVal($("#personName"), "Test Friend");
  $("#addPersonBtn").click();
  st = API.getState();
  ok(st.people.length === 6, "person added", st.people.length);
  ok(st.people[5].name === "Test Friend", "name stored correctly");
  ok($("#personName").value === "", "input cleared after add");
  setVal($("#personName"), "test friend");
  $("#addPersonBtn").click();
  ok(API.getState().people.length === 6, "duplicate name (case-insensitive) is rejected");

  section("4. Add an expense (equal split, subset of people)");
  const before = API.getState().expenses.length;
  setVal($("#expTitle"), "Test dinner");
  setVal($("#expAmount"), "1000");
  // deselect everyone except the first three
  $$("#splitList .split-row").forEach((row, i) => {
    const cb = row.querySelector(".split-check");
    if(i > 2 && cb.checked){ cb.checked = false; cb.dispatchEvent(new window.Event("change", { bubbles:true })); }
  });
  submitForm();
  st = API.getState();
  ok(st.expenses.length === before + 1, "expense added to state", st.expenses.length);
  const added = st.expenses[st.expenses.length - 1];
  ok(added.amount === 100000, "amount stored in integer paise", added.amount);
  ok(Object.keys(added.shares).length === 3, "only the 3 selected people share it", Object.keys(added.shares).length);
  const sharesSum = Object.values(added.shares).reduce((a,b)=>a+b,0);
  ok(sharesSum === 100000, "shares sum exactly to the amount (no floating drift)", sharesSum);
  ok($$("#expenseList .exp").length === 7, "ledger row rendered");
  ok($("#expTitle").value === "", "form resets after submit");

  section("5. Custom split validation");
  setVal($("#expTitle"), "Custom split test");
  setVal($("#expAmount"), "100");
  $$(".tab").find(t => t.dataset.mode === "custom").click();
  const inputs = $$("#splitList .split-input");
  ok(inputs.length > 0, "custom mode shows per-person amount inputs");
  inputs.forEach(i => { i.value = ""; i.dispatchEvent(new window.Event("input", { bubbles:true })); });
  let expCount = API.getState().expenses.length;
  submitForm();
  ok(API.getState().expenses.length === expCount, "submitting an unbalanced custom split is blocked");
  ok($("#errSplit").textContent.length > 0, "error message shown for unbalanced custom split", $("#errSplit").textContent);
  // now balance it: first input gets everything
  const rows = $$("#splitList .split-row");
  const firstInput = rows[0].querySelector(".split-input");
  firstInput.value = "100";
  firstInput.dispatchEvent(new window.Event("input", { bubbles:true }));
  submitForm();
  st = API.getState();
  ok(st.expenses.length === expCount + 1, "balanced custom split is accepted", st.expenses.length);
  const custom = st.expenses[st.expenses.length - 1];
  ok(custom.mode === "custom", "mode stored as custom");
  ok(Object.values(custom.shares).reduce((a,b)=>a+b,0) === 10000, "custom shares sum exactly");

  section("6. Percent split");
  setVal($("#expTitle"), "Percent test");
  setVal($("#expAmount"), "999.99");
  $$(".tab").find(t => t.dataset.mode === "percent").click();
  const pctInputs = $$("#splitList .split-input");
  const pctSum = pctInputs.reduce((a,i)=>a + parseFloat(i.value || "0"), 0);
  ok(Math.abs(pctSum - 100) < 1e-9, "percent inputs prefill to exactly 100.00", pctSum);
  submitForm();
  st = API.getState();
  const pctExp = st.expenses[st.expenses.length - 1];
  ok(pctExp && pctExp.title === "Percent test", "percent expense added");
  ok(Object.values(pctExp.shares).reduce((a,b)=>a+b,0) === 99999, "percent shares sum exactly to 999.99", Object.values(pctExp.shares).reduce((a,b)=>a+b,0));

  section("7. Edit an expense");
  const target = API.getState().expenses[1];
  const editBtn = $$("#expenseList .exp").map(r => r.querySelector('[data-action="edit-expense"]')).find(b => b.dataset.id === target.id);
  editBtn.click();
  ok($("#formCard").classList.contains("editing"), "form switches into edit mode");
  ok($("#expTitle").value === target.title, "title prefilled", $("#expTitle").value);
  ok($("#expPaidBy").value === target.paidBy, "payer prefilled");
  const countBeforeEdit = API.getState().expenses.length;
  setVal($("#expAmount"), "2222");
  submitForm();
  st = API.getState();
  const edited = st.expenses.find(e => e.id === target.id);
  ok(edited.amount === 222200, "edited amount persisted", edited.amount);
  ok(!$("#formCard").classList.contains("editing"), "form returns to add mode after save");
  ok(st.expenses.length === countBeforeEdit, "no duplicate expense created by the edit", st.expenses.length);

  section("8. Delete + undo");
  const delTarget = API.getState().expenses[0];
  const n0 = API.getState().expenses.length;
  $$("#expenseList .exp").map(r => r.querySelector('[data-action="delete-expense"]')).find(b => b.dataset.id === delTarget.id).click();
  ok(API.getState().expenses.length === n0 - 1, "expense deleted");
  const undoBtn = $$("#toasts .t-act").pop();
  ok(!!undoBtn, "undo toast offered");
  undoBtn.click();
  ok(API.getState().expenses.length === n0, "undo restores the expense");
  ok(API.getState().expenses.some(e => e.id === delTarget.id), "restored expense keeps its id");

  section("9. Remove a person cascades safely");
  const victim = API.getState().people.find(p => p.name === "Test Friend");
  const rowsBefore = API.getState().expenses.length;
  $$("#peopleList .chip .x").find(b => b.dataset.id === victim.id).click();
  const modalOk = document.querySelector('.modal [data-role="ok"]');
  ok(!!modalOk, "confirm dialog appears when the person has expenses");
  modalOk.click();
  setTimeout(afterPersonRemoval, 30);

  function afterPersonRemoval(){
    st = API.getState();
    ok(!st.people.some(p => p.id === victim.id), "person removed");
    ok(st.expenses.length < rowsBefore, "their expenses were removed with them", { before: rowsBefore, after: st.expenses.length });
    const L2 = API.ledger();
    ok(Object.values(L2.net).reduce((a,b)=>a+b,0) === 0, "balances still sum to zero after cascade");
    ok(st.expenses.every(e => e.shares[victim.id] === undefined), "no orphan shares remain");

    section("10. Persistence, currency, theme");
    const raw = window.localStorage.getItem("smartsplit.v1");
    ok(!!raw, "state written to localStorage");
    const parsed = JSON.parse(raw);
    ok(parsed.expenses.length === st.expenses.length, "persisted expenses match memory");

    $("#currencySelect").value = "USD";
    $("#currencySelect").dispatchEvent(new window.Event("change", { bubbles:true }));
    ok($("#statTotal").textContent.includes("$"), "currency switch reformats amounts", $("#statTotal").textContent);
    $("#currencySelect").value = "INR";
    $("#currencySelect").dispatchEvent(new window.Event("change", { bubbles:true }));

    const t0 = document.documentElement.getAttribute("data-theme");
    $("#themeToggle").click();
    const t1 = document.documentElement.getAttribute("data-theme");
    ok(t0 !== t1, "theme toggle flips the theme", { t0, t1 });

    section("11. Search & sort");
    setVal($("#searchInput"), "zzzz-no-match");
    ok($("#expenseList").textContent.includes("No expenses match"), "empty search state shown");
    setVal($("#searchInput"), "");
    $("#sortSelect").value = "high";
    $("#sortSelect").dispatchEvent(new window.Event("change", { bubbles:true }));
    const amts = $$("#expenseList .exp .amt").map(n => parseFloat(n.textContent.replace(/[^0-9.]/g, "")));
    ok(amts.every((v,i,a) => i === 0 || a[i-1] >= v), "sorted high → low", amts);

    section("12. Reset");
    $("#resetBtn").click();
    const resetOk = document.querySelector('.modal [data-role="ok"]');
    resetOk.click();
    setTimeout(() => {
      const s2 = API.getState();
      ok(s2.people.length === 0 && s2.expenses.length === 0, "reset clears everything");
      ok($("#settlementList").textContent.length > 0, "empty settlement state renders");
      ok($("#submitExpenseBtn").disabled === true, "submit disabled with no people");

      console.log("\n" + (failures === 0 ? "ALL " + checks + " CHECKS PASSED ✅" : failures + " of " + checks + " CHECKS FAILED ❌"));
      process.exit(failures === 0 ? 0 : 1);
    }, 30);
  }
}

window.addEventListener("error", e => { console.log("PAGE ERROR:", e.message); });
