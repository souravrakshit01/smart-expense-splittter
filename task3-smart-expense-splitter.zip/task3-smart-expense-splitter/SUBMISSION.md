# 📎 Submission links & deploy

**Project:** SplitSmart — Smart Expense Splitter (Task 3, First Year · Coding Ninjas 10X SRM Web Dev Recruitment)

---

## Paste-ready blurb (drop this in your Google Doc / Drive submission)

> **Task 3 — Smart Expense Splitter ("SplitSmart")**
> A responsive expense-splitting web app built with HTML, CSS and vanilla JavaScript.
> It lets a group add participants, record expenses (amount, payer, who shared it), and
> instantly calculates each person's total paid, fair share and net balance, followed by a
> settlement plan that clears all debts in the fewest possible payments.
>
> **Live demo:** `<paste your permanent URL here>`
> **Source code:** `index.html` (single file, no dependencies) — attached below
>
> Bonuses delivered: edit/delete expenses with Undo, localStorage persistence,
> three split modes (equal / exact / percentage), CSV export, print-to-PDF report,
> dark & light themes, and exact integer (paise) arithmetic so splits never round off.

---

## 1) Live link you can share right now

```
https://8000-ikw2m4og9tbldce8tefya.e2b.app
```

⚠️ This URL is served from the temporary preview session, so it works while the session is
alive and stops working later. **Do not submit this as your final link** — use one of the
permanent options below (takes ~2 minutes).

---

## 2) Permanent link — GitHub Pages (recommended, free forever)

You already have a GitHub account (`souravrakshit01`), and deployment is mandatory for the
second-year tasks — good habit to start now.

**No-terminal route (easiest):**

1. Go to <https://github.com/new> → Repository name: `smart-expense-splitter` → **Public** → Create.
2. On the new repo page click **uploading an existing file**.
3. Drag in **`index.html`** (rename it if you like, keep the name `index.html`) + optional `README.md`.
4. Commit changes.
5. Repo → **Settings** → **Pages** → *Source*: `Deploy from a branch` → Branch: **main** / **(root)** → **Save**.
6. Wait ~60 seconds, refresh — your link appears:

```
https://souravrakshit01.github.io/smart-expense-splitter/
```

**Terminal route (if you prefer git):**

```bash
cd task3-smart-expense-splitter
git init && git add . && git commit -m "Task 3 - Smart Expense Splitter"
git branch -M main
git remote add origin https://github.com/souravrakshit01/smart-expense-splitter.git
git push -u origin main
# then enable Pages in Settings -> Pages, as in step 5 above
```

---

## 3) Alternative permanent link — Netlify Drop (no account needed to start)

1. Open <https://app.netlify.com/drop>
2. Drag the whole **`task3-smart-expense-splitter`** folder onto the page.
3. You instantly get a URL like `https://random-name-12345.netlify.app` → paste that in Drive.
   (You can rename the site or claim it to a free account to keep it permanently.)

---

## 4) What to attach in Google Drive

Upload these into your Drive submission folder:

| File | Why |
|---|---|
| `smart-expense-splitter/index.html` | The complete, runnable source code (single file, no dependencies) |
| `task3-smart-expense-splitter.zip` | Zipped project (source + README + tests) for one-click download |
| `README.md` | Documents features, requirement coverage, the maths and the deploy steps |
| `tests/smoke-test.js` | 63 automated checks — proof the calculations are correct ✅ |

**Tell the reviewer:** *"Download `index.html` and open it in any browser — no installation,
server or internet connection required."* (Google Drive previews HTML as plain text, so the
file needs to be downloaded to run.)

---

## 5) Verify it works after download

```bash
# optional: run the automated test suite
npm init -y
npm i -D jsdom
node tests/smoke-test.js      # → ALL 63 CHECKS PASSED ✅
```
