# 💸 SplitSmart — Smart Expense Splitter

A clean, fast expense‑splitting web app for trips, outings and events. Add the people, record who paid for what, and SplitSmart instantly shows **who owes whom** — plus a settlement plan that clears every debt in the **fewest possible payments**.

Built for **Coding Ninjas 10X SRM — Web Dev Recruitment Tasks (First Year, Task 3)** using **HTML + CSS + vanilla JavaScript**. No frameworks, no build step, no external requests — one file that runs anywhere.

---

## 🚀 Run it

**Option 1 — just open it**

Double‑click `index.html` (works in any modern browser).

**Option 2 — tiny local server** (recommended if you want `localStorage` to behave exactly like on a real host)

```bash
# from this folder
python3 -m http.server 8000
# then open http://localhost:8000
```

On first run, SplitSmart loads a **sample 5‑person trip** so you can see every feature immediately. Hit **Reset** in the People panel to start your own group.

---

## ✅ Requirement coverage

### Minimum requirements (from the task PDF)

| Requirement | Where it lives |
|---|---|
| Allow users to add participants to a group | **People** panel — add by name, duplicate names are rejected, each person gets a colour + initials avatar |
| Record expenses incl. amount, payer and participants involved | **Add an expense** form — title, amount, paid‑by, date, category, and a per‑person split list |
| Calculate each participant's total contribution and share | **Balances** panel + People chips show `paid ₹X · share ₹Y` for every person |
| Display each participant's net balance (who owes / who receives) | **Balances** panel — `gets back` (green) / `owes` (red) / `settled up`, with a visual diverging bar |
| Generate a settlement plan showing who should pay whom | **Settle up** panel — greedy debt simplification, ≤ (people − 1) transfers |
| Handle calculations dynamically using JavaScript | Every keystroke updates previews, balances and the plan live — no page reloads |
| Make the website responsive | CSS Grid auto‑reflows: 3 columns → 2 → 1, tested from 320 px phones to wide desktops |

### Bonus requirements

- ✅ **Edit or delete expenses** — hover a row in the Expense log to edit (form switches into edit mode) or delete (with a 6‑second **Undo** toast)
- ✅ **Store expenses using localStorage** — the whole group (people, expenses, currency, theme, group name) survives refreshes; if storage is blocked (e.g. inside a sandboxed preview) it transparently falls back to in‑memory storage and tells you
- ✅ **Deploy the website** — instructions below (GitHub Pages / Vercel / Netlify); it's a static single file, so anything works

### Extra polish (beyond the brief)

- Three split modes: **Equally**, **Exact amounts**, and **Percentages**
- Integer **paise/cents arithmetic** — splits always add up *exactly*, never ₹0.01 off
- Settlement optimiser: the minimum number of transfers, with a "🎉 everyone is settled up" state
- Multi‑currency (₹ / $ / € / £) via `Intl.NumberFormat`
- Live search, sorting by date/amount, category icons, per‑expense date
- **Copy summary**, **Export CSV**, and a **Print / PDF report** layout
- Dark & light themes (follows your OS on first visit), persisted
- Toast notifications, confirm dialogs, focus‑visible outlines, `aria-live` regions, reduced‑motion support
- Empty states everywhere, so the app never looks broken
- Demo trip loader + hard reset

---

## 🧠 How the maths stays accurate

This is the part interviewers poke at, so it's done properly:

**1. Money is stored as integers (paise/cents), never floats.**
`₹1240.55` is stored as `124055`. Adding, subtracting and splitting integers has zero floating‑point drift.

**2. Splitting uses the largest‑remainder method.**
`allocate(totalPaise, weights)` distributes the total proportionally and then hands the leftover paise to the people with the largest fractional remainders, so **the parts always sum exactly to the total**:

```js
allocate(1000, [1, 1, 1])  // → [334, 333, 333]  (not 333.33 × 3)
```

The same function powers equal splits, weighted percentage splits and the "reset to even" prefill.

**3. Balances are a double‑entry check.**
For every person: `paid = Σ expenses they paid` and `share = Σ their slices`, then `net = paid − share`. Because every expense's shares sum to its amount, **the sum of all nets is always exactly 0** — the smoke test asserts this after every operation.

**4. Settlement uses greedy debt simplification.**
Creditors (net > 0) and debtors (net < 0) are sorted by size and matched largest‑against‑largest. Each pass zeroes out at least one person, so the plan needs **at most (people − 1) transfers** — and the transfers always total exactly what creditors are owed.

---

## 🗂 Project structure

```
task3-smart-expense-splitter/
├── index.html          # the entire app: markup + styles + logic (zero dependencies)
├── README.md           # this file
└── tests/
    └── smoke-test.js   # 63 automated checks that drive the real UI in jsdom
```

---

## 🧪 Tests

The smoke test boots the real `index.html` in [jsdom](https://github.com/jsdom/jsdom) and drives it like a user: adds people, submits the form, switches split modes, edits, deletes, undoes, removes a participant, tweaks currency/theme, searches, sorts and resets — then asserts the maths on every step.

```bash
npm init -y
npm i -D jsdom
node tests/smoke-test.js
```

```
ALL 63 CHECKS PASSED ✅
```

Notable assertions: `Σ net === 0` after every mutation, shares sum exactly to the amount in all three split modes, unbalanced custom splits are blocked, settlement covers exactly what creditors are owed, cascading a person‑removal leaves no orphan shares, and state round‑trips through `localStorage`.

---

## ☁️ Deploy it

### GitHub Pages (fastest)

```bash
cd task3-smart-expense-splitter
git init
git add .
git commit -m "Task 3 — Smart Expense Splitter"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

Then on GitHub: **Settings → Pages → Source: Deploy from a branch → main / (root) → Save**.
Your app goes live at `https://<your-username>.github.io/<repo-name>/` in ~1 minute.

### Vercel

1. Push the folder to GitHub (as above), then on [vercel.com](https://vercel.com) → **Add New → Project → Import** the repo.
2. Framework preset: **Other**. Build command: *(empty)*. Output directory: *(empty / `.`)*.
3. **Deploy** — you get a `https://your-project.vercel.app` URL.

### Netlify (drag & drop)

Open [app.netlify.com/drop](https://app.netlify.com/drop) and drag this folder in. Done.

---

## 🕹 Quick tour (30 seconds)

1. The **People** panel already has a sample group — add or remove anyone.
2. In **Add an expense**, type `Dinner`, `1200`, pick who paid, then switch between **Equally / Exact amounts / Percentages** and watch the per‑person previews update live.
3. Press **Add expense** — the log, balances and settlement plan update instantly.
4. Hover any row in the **Expense log** to **edit** ✏️ or **delete** 🗑️ (with Undo).
5. Hit **Copy settlement plan**, **Export CSV**, or **Print / PDF** to share the outcome.

### Handy keyboard bits

- `Enter` in the name field → adds a person
- `Enter` anywhere in the expense form → submits it
- `Esc` → closes a confirm dialog
- `Tab` → every control is reachable (focus rings included)

---

## 🔍 Debug API

For quick console experiments (and for the tests), the app exposes a tiny read‑only surface:

```js
SplitSmart.getState()          // deep copy of people + expenses
SplitSmart.ledger()            // { paid, share, net, total } in paise
SplitSmart.allocate(1000, [1,1,1])   // [334, 333, 333]
SplitSmart.settleUp({ a: 500, b: -500 })  // [{ from, to, amount }]
```

---

## 📄 License

Free to use for your submission, portfolio and learning. Built as a single self‑contained file — copy it, restyle it, extend it.
